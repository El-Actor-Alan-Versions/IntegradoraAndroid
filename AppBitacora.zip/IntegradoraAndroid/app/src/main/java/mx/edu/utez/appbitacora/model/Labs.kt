package mx.edu.utez.appbitacora.model

data class Labs(
    val id : Long,
    val nomLab : String,
    val docencia : Int,
    val estatus : Boolean
)